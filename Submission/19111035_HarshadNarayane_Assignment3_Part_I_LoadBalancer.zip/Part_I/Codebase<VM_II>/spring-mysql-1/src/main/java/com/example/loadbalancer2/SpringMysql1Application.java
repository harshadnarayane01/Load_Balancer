package com.example.loadbalancer2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMysql1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringMysql1Application.class, args);
	}

}
