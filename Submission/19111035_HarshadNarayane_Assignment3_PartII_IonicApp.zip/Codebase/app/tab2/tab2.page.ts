import { Component } from '@angular/core';
import { BluetoothLE } from '@ionic-native/bluetooth-le/ngx';
import { Platform } from '@ionic/angular';
import { BLE } from '@ionic-native/ble/ngx';
import { ToastController } from '@ionic/angular';
import { ThrowStmt } from '@angular/compiler';


@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss']
})
export class Tab2Page {
  public isToggled: boolean;
  toast:ToastController;
  constructor(
      public bluetoothle: BLE,
      public bluetoothClassic: BluetoothLE,
      public plt: Platform,
      public toastController: ToastController) {
          this.isToggled = false;
          this.switchBluetoothState();
  }
/**
 * function switchBluetoothState() :
 * The function will check the value of ion-toggle. 
 * If it is true, i.e. toggle is on, then it will enable the bluetooth.
 * If it is false, it will disable the bluetooth ( Plugin dependent behavior ).
 * And will show customized toast message.
 */
  switchBluetoothState() {
    
    if ( this.isToggled ) {
      this.bluetoothle.enable();
    }
    else {
      this.bluetoothClassic.disable();
      this.showToast();
    }
  }
  /**
   * function showToast() :
   * Showing Toast Message after toggling off the bluetooth.
   */
  showToast() {
      this.toastController.create({
      message: "The  off functionality in BluetoothLE Ionic Plugin doesn't work...",
      duration: 2000
    }).then((toastData)=>{
      toastData.present();
    });
  }
  /**
   * function HideToast():
   * For hiding toast.
   */
  HideToast() {
    this.toastController.dismiss();
  }
}
