import { Component,ViewChild } from '@angular/core';
import { PhotoService } from '../services/photo.service';
import { NavController } from '@ionic/angular';
import { MediaCapture, MediaFile, CaptureError, CaptureVideoOptions } from '@ionic-native/media-capture/ngx';
import { Storage } from '@ionic/storage';
import { Media, MediaObject } from '@ionic-native/media/ngx';
import { File } from '@ionic-native/file/ngx';

const MEDIA_FILES_KEY = 'mediaFiles';

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page {
  /**
   * function ngOnInit():
   * This will be called on page load and will bring the images that has 
   * been stored in the local data storage. 
   */
  ngOnInit() {
    this.photoService.loadSaved();
  }
  mediaFiles = [];
  @ViewChild('myvideo',{static: false}) myVideo: any;

  constructor(public photoService: PhotoService,
    public navCtrl: NavController, private mediaCapture: MediaCapture, private storage: Storage, private file: File, private media: Media
    ) {  }
    

    ionViewDidLoad() {
      this.storage.get(MEDIA_FILES_KEY).then(res => {
        this.mediaFiles = JSON.parse(res) || [];
      })
    }
   /**
    * function captureAudio():
    * Captures audio and store the result. 
    */
    captureAudio() {
      this.mediaCapture.captureAudio().then(res => {
        this.storeMediaFiles(res);
      }, (err: CaptureError) => console.error(err));
    }
   
    /**
     * function captureVideo():
     * Captures the video for duration of 30 seconds. 
     */
    captureVideo() {
      let options: CaptureVideoOptions = {
        limit: 1,
        duration: 30
      }
      this.mediaCapture.captureVideo(options).then((res: MediaFile[]) => {
        let capturedFile = res[0];
        let fileName = capturedFile.name;
        let dir = capturedFile['localURL'].split('/');
        dir.pop();
        let fromDirectory = dir.join('/');      
        var toDirectory = this.file.dataDirectory;
        
        this.file.copyFile(fromDirectory , fileName , toDirectory , fileName).then((res) => {
          this.storeMediaFiles([{name: fileName, size: capturedFile.size}]);
        },err => {
          console.log('err: ', err);
        });
            },
      (err: CaptureError) => console.error(err));
    }
   /**
    * function play():
    * Plays the audio and video files.
    * @param myFile : The intended file to play.
    */
    play(myFile) {
      if (myFile.name.indexOf('.wav') > -1) {
        const audioFile: MediaObject = this.media.create(myFile.localURL);
        audioFile.play();
      } else {
        let path = this.file.dataDirectory + myFile.name;
        let url = path.replace(/^file:\/\//, '');
        let video = this.myVideo.nativeElement;
        video.src = url;
        video.play();
      }
    }
   /**
    * function storeMediaFiles(files) :
    * Stores the media files
    * @param files : The files to store.
    */
    storeMediaFiles(files) {
      this.storage.get(MEDIA_FILES_KEY).then(res => {
        if (res) {
          let arr = JSON.parse(res);
          arr = arr.concat(files);
          this.storage.set(MEDIA_FILES_KEY, JSON.stringify(arr));
        } else {
          this.storage.set(MEDIA_FILES_KEY, JSON.stringify(files))
        }
        this.mediaFiles = this.mediaFiles.concat(files);
      })
    }

  
  }
